var searchData=
[
  ['destroyturingmachine_0',['DestroyTuringMachine',['../_turing_d_l_l_8cpp.html#a41635734eb6e8dab1cfe1e4d156f67b8',1,'DestroyTuringMachine(TuringMachine *tm):&#160;TuringDLL.cpp'],['../_turing_d_l_l_8h.html#ad2a1ae8ff677806dd1ef577a429b7264',1,'DestroyTuringMachine(TuringMachine *tm):&#160;TuringDLL.cpp']]],
  ['direction_1',['direction',['../struct_command.html#a97f7772941bb2e6262ae0d6d4deb1487',1,'Command']]],
  ['dllmain_2',['DllMain',['../dllmain_8cpp.html#a26e64fb39b69bcd9d1274d279f1561b9',1,'dllmain.cpp']]],
  ['dllmain_2ecpp_3',['dllmain.cpp',['../dllmain_8cpp.html',1,'']]]
];
