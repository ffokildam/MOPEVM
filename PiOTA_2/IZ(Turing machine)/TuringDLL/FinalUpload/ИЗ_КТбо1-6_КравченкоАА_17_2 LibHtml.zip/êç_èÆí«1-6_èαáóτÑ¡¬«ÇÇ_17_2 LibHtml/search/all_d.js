var searchData=
[
  ['описание_0',['Описание',['../index.html#intro_sec',1,'']]]
];
