var searchData=
[
  ['destroyturingmachine_0',['DestroyTuringMachine',['../_turing_d_l_l_8cpp.html#a41635734eb6e8dab1cfe1e4d156f67b8',1,'DestroyTuringMachine(TuringMachine *tm):&#160;TuringDLL.cpp'],['../_turing_d_l_l_8h.html#ad2a1ae8ff677806dd1ef577a429b7264',1,'DestroyTuringMachine(TuringMachine *tm):&#160;TuringDLL.cpp']]],
  ['dllmain_1',['DllMain',['../dllmain_8cpp.html#a26e64fb39b69bcd9d1274d279f1561b9',1,'dllmain.cpp']]]
];
