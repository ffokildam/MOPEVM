var searchData=
[
  ['moveleft_0',['moveLeft',['../class_tape.html#a2e143a0f3de65e626e7d030b2b698ada',1,'Tape']]],
  ['moveright_1',['moveRight',['../class_tape.html#a045da6e9cc8d21024d89c0bee6e639f6',1,'Tape']]]
];
