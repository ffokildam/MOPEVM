var searchData=
[
  ['cleartape_0',['clearTape',['../class_tape.html#ab353d5322007b8a4e5b5b3e7011e42b3',1,'Tape']]],
  ['command_1',['Command',['../struct_command.html',1,'']]],
  ['createturingmachine_2',['CreateTuringMachine',['../_turing_d_l_l_8cpp.html#a6d82caf7f6fb009b2b862e2cac7d0c76',1,'CreateTuringMachine(const std::map&lt; std::string, std::map&lt; char, Command &gt; &gt; &amp;program, const std::string &amp;initialState, const std::string &amp;initialTape):&#160;TuringDLL.cpp'],['../_turing_d_l_l_8h.html#ad0a03b0958afa86d157aa9db9ccf2d89',1,'CreateTuringMachine(const std::map&lt; std::string, std::map&lt; char, Command &gt; &gt; &amp;program, const std::string &amp;initialState, const std::string &amp;initialTape):&#160;TuringDLL.cpp']]]
];
