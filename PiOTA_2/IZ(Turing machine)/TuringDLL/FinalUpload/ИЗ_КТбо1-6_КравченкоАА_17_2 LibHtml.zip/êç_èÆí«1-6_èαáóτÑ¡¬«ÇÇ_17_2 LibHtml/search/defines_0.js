var searchData=
[
  ['turingdll_5fapi_0',['TURINGDLL_API',['../_turing_d_l_l_8h.html#ae2dd35b29e492097473c122f3b667f5b',1,'TuringDLL.h']]]
];
