var searchData=
[
  ['nextstate_0',['nextState',['../struct_command.html#a02147b5f88ea511d41357ff71bbea485',1,'Command']]]
];
