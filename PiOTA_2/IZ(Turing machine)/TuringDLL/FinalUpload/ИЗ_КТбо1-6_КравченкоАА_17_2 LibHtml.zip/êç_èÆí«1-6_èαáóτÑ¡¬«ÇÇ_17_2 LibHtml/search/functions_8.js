var searchData=
[
  ['write_0',['write',['../class_tape.html#a106da612b72ead6e926ff2b36fb7a80d',1,'Tape']]]
];
