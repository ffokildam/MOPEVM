var searchData=
[
  ['read_0',['read',['../class_tape.html#ab8ff70f09fd81b9c23b561ee58e9f85c',1,'Tape']]],
  ['run_1',['run',['../class_turing_machine.html#ae492842d3d54a0e041feb5bf3ad8dfaf',1,'TuringMachine']]]
];
