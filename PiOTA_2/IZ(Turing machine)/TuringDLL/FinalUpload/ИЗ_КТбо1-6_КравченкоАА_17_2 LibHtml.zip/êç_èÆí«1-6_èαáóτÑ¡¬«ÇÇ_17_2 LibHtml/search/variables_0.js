var searchData=
[
  ['direction_0',['direction',['../struct_command.html#a97f7772941bb2e6262ae0d6d4deb1487',1,'Command']]]
];
